"""
Document Verification System for BlueDwarf
Handles state ID and professional license verification
"""

import cv2
import numpy as np
import pytesseract
import requests
import boto3
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import re
import json
import os
from PIL import Image
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentVerifier:
    """
    Comprehensive document verification system for state IDs and professional licenses
    """
    
    def __init__(self):
        """Initialize the document verifier with API clients"""
        self.rekognition = boto3.client(
            'rekognition',
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
            region_name=os.getenv('AWS_REGION', 'us-east-1')
        )
        
        self.id_analyzer_api_key = os.getenv('ID_ANALYZER_API_KEY')
        self.id_analyzer_url = "https://api.idanalyzer.com"
        
        # State ID patterns and validation rules
        self.state_id_patterns = {
            'CA': r'^[A-Z]\d{7}$',
            'TX': r'^\d{8}$',
            'FL': r'^[A-Z]\d{12}$',
            'NY': r'^\d{9}$',
            'WA': r'^[A-Z0-9]{12}$',
            # Add more state patterns as needed
        }
        
        # Professional license patterns by state and profession
        self.license_patterns = {
            'real_estate': {
                'CA': r'^0\d{7}$',
                'TX': r'^\d{6}$',
                'FL': r'^[A-Z]{2}\d{7}$',
                'NY': r'^\d{8}$',
                'WA': r'^\d{8}$'
            },
            'mortgage': {
                'CA': r'^CA-MLO\d{8}$',
                'TX': r'^\d{6}$',
                'FL': r'^LO\d{8}$',
                'NY': r'^\d{8}$',
                'WA': r'^\d{8}$'
            }
        }

    def verify_document_authenticity(self, image_path: str) -> Dict:
        """
        Verify document authenticity using AWS Rekognition and ID Analyzer
        
        Args:
            image_path: Path to the document image
            
        Returns:
            Dict containing verification results
        """
        try:
            # Read image
            with open(image_path, 'rb') as image_file:
                image_bytes = image_file.read()
            
            # AWS Rekognition document analysis
            rekognition_result = self._analyze_with_rekognition(image_bytes)
            
            # ID Analyzer verification
            id_analyzer_result = self._analyze_with_id_analyzer(image_path)
            
            # Combine results
            verification_result = {
                'authentic': True,
                'confidence_score': 0.0,
                'fraud_indicators': [],
                'document_type': None,
                'extracted_data': {},
                'verification_details': {
                    'rekognition': rekognition_result,
                    'id_analyzer': id_analyzer_result
                }
            }
            
            # Analyze results for authenticity
            verification_result = self._analyze_authenticity(verification_result)
            
            return verification_result
            
        except Exception as e:
            logger.error(f"Document verification error: {str(e)}")
            return {
                'authentic': False,
                'confidence_score': 0.0,
                'fraud_indicators': ['verification_error'],
                'error': str(e)
            }

    def _analyze_with_rekognition(self, image_bytes: bytes) -> Dict:
        """Analyze document using AWS Rekognition"""
        try:
            # Detect text in document
            text_response = self.rekognition.detect_text(
                Image={'Bytes': image_bytes}
            )
            
            # Analyze document quality
            quality_response = self.rekognition.detect_faces(
                Image={'Bytes': image_bytes},
                Attributes=['ALL']
            )
            
            return {
                'text_detections': text_response.get('TextDetections', []),
                'face_details': quality_response.get('FaceDetails', []),
                'success': True
            }
            
        except Exception as e:
            logger.error(f"Rekognition analysis error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def _analyze_with_id_analyzer(self, image_path: str) -> Dict:
        """Analyze document using ID Analyzer API"""
        try:
            if not self.id_analyzer_api_key:
                return {'success': False, 'error': 'ID Analyzer API key not configured'}
            
            # Prepare API request
            files = {'document': open(image_path, 'rb')}
            headers = {'X-API-KEY': self.id_analyzer_api_key}
            
            # Make API request
            response = requests.post(
                f"{self.id_analyzer_url}/scan",
                files=files,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {'success': False, 'error': f'API error: {response.status_code}'}
                
        except Exception as e:
            logger.error(f"ID Analyzer error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def extract_text_from_document(self, image_path: str) -> Dict:
        """
        Extract text from document using OCR
        
        Args:
            image_path: Path to the document image
            
        Returns:
            Dict containing extracted text and structured data
        """
        try:
            # Load and preprocess image
            image = cv2.imread(image_path)
            processed_image = self._preprocess_image(image)
            
            # Extract text using Tesseract OCR
            text = pytesseract.image_to_string(processed_image)
            
            # Extract structured data
            structured_data = self._parse_document_text(text)
            
            return {
                'raw_text': text,
                'structured_data': structured_data,
                'success': True
            }
            
        except Exception as e:
            logger.error(f"Text extraction error: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }

    def _preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """Preprocess image for better OCR results"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply noise reduction
        denoised = cv2.fastNlMeansDenoising(gray)
        
        # Apply adaptive thresholding
        thresh = cv2.adaptiveThreshold(
            denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
        
        return thresh

    def _parse_document_text(self, text: str) -> Dict:
        """Parse extracted text to identify document fields"""
        structured_data = {}
        
        # Common patterns for document parsing
        patterns = {
            'name': r'(?:NAME|FULL NAME)[:\s]+([A-Z\s]+)',
            'date_of_birth': r'(?:DOB|DATE OF BIRTH|BORN)[:\s]+(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
            'license_number': r'(?:LICENSE|LIC|ID)[:\s#]+([A-Z0-9]+)',
            'expiration_date': r'(?:EXP|EXPIRES|EXPIRATION)[:\s]+(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
            'state': r'(?:STATE|ST)[:\s]+([A-Z]{2})',
            'address': r'(?:ADDRESS|ADDR)[:\s]+([A-Z0-9\s,]+)'
        }
        
        for field, pattern in patterns.items():
            match = re.search(pattern, text.upper())
            if match:
                structured_data[field] = match.group(1).strip()
        
        return structured_data

    def validate_license_format(self, license_number: str, state: str, profession: str) -> bool:
        """
        Validate license number format for specific state and profession
        
        Args:
            license_number: License number to validate
            state: State abbreviation (e.g., 'CA', 'TX')
            profession: Profession type (e.g., 'real_estate', 'mortgage')
            
        Returns:
            bool: True if format is valid
        """
        try:
            if profession in self.license_patterns and state in self.license_patterns[profession]:
                pattern = self.license_patterns[profession][state]
                return bool(re.match(pattern, license_number.upper()))
            
            return False
            
        except Exception as e:
            logger.error(f"License validation error: {str(e)}")
            return False

    def check_expiration_date(self, expiration_date: str) -> Dict:
        """
        Check if document is expired
        
        Args:
            expiration_date: Expiration date string
            
        Returns:
            Dict containing expiration status
        """
        try:
            # Parse date (handle multiple formats)
            date_formats = ['%m/%d/%Y', '%m-%d-%Y', '%m/%d/%y', '%m-%d-%y']
            parsed_date = None
            
            for fmt in date_formats:
                try:
                    parsed_date = datetime.strptime(expiration_date, fmt)
                    break
                except ValueError:
                    continue
            
            if not parsed_date:
                return {'valid': False, 'error': 'Invalid date format'}
            
            # Check if expired
            current_date = datetime.now()
            is_expired = parsed_date < current_date
            days_until_expiry = (parsed_date - current_date).days
            
            return {
                'valid': True,
                'expired': is_expired,
                'expiration_date': parsed_date.isoformat(),
                'days_until_expiry': days_until_expiry,
                'expires_soon': days_until_expiry <= 30 and days_until_expiry > 0
            }
            
        except Exception as e:
            logger.error(f"Date validation error: {str(e)}")
            return {'valid': False, 'error': str(e)}

    def _analyze_authenticity(self, verification_result: Dict) -> Dict:
        """Analyze verification results to determine authenticity"""
        fraud_indicators = []
        confidence_score = 100.0
        
        # Check Rekognition results
        rekognition_data = verification_result['verification_details']['rekognition']
        if rekognition_data.get('success'):
            # Analyze text quality
            text_detections = rekognition_data.get('text_detections', [])
            if len(text_detections) < 5:
                fraud_indicators.append('insufficient_text')
                confidence_score -= 20
            
            # Analyze face quality (for IDs with photos)
            face_details = rekognition_data.get('face_details', [])
            if face_details:
                face = face_details[0]
                if face.get('Quality', {}).get('Brightness', 0) < 30:
                    fraud_indicators.append('poor_image_quality')
                    confidence_score -= 15
        
        # Check ID Analyzer results
        id_analyzer_data = verification_result['verification_details']['id_analyzer']
        if id_analyzer_data.get('success'):
            # Check for fraud indicators from ID Analyzer
            if id_analyzer_data.get('fraud_score', 0) > 50:
                fraud_indicators.append('high_fraud_score')
                confidence_score -= 30
        
        # Update verification result
        verification_result['fraud_indicators'] = fraud_indicators
        verification_result['confidence_score'] = max(0, confidence_score)
        verification_result['authentic'] = confidence_score >= 70 and len(fraud_indicators) == 0
        
        return verification_result

    def verify_state_id(self, image_path: str) -> Dict:
        """
        Complete state ID verification workflow
        
        Args:
            image_path: Path to state ID image
            
        Returns:
            Dict containing complete verification results
        """
        try:
            # Step 1: Verify document authenticity
            auth_result = self.verify_document_authenticity(image_path)
            
            # Step 2: Extract text and data
            text_result = self.extract_text_from_document(image_path)
            
            # Step 3: Validate extracted data
            validation_result = {}
            if text_result.get('success'):
                structured_data = text_result['structured_data']
                
                # Check expiration date
                if 'expiration_date' in structured_data:
                    validation_result['expiration'] = self.check_expiration_date(
                        structured_data['expiration_date']
                    )
                
                # Validate ID format
                if 'license_number' in structured_data and 'state' in structured_data:
                    state = structured_data['state']
                    id_number = structured_data['license_number']
                    if state in self.state_id_patterns:
                        validation_result['format_valid'] = bool(
                            re.match(self.state_id_patterns[state], id_number)
                        )
            
            # Combine all results
            complete_result = {
                'verification_type': 'state_id',
                'authentic': auth_result.get('authentic', False),
                'confidence_score': auth_result.get('confidence_score', 0),
                'fraud_indicators': auth_result.get('fraud_indicators', []),
                'extracted_data': text_result.get('structured_data', {}),
                'validation_results': validation_result,
                'timestamp': datetime.now().isoformat()
            }
            
            return complete_result
            
        except Exception as e:
            logger.error(f"State ID verification error: {str(e)}")
            return {
                'verification_type': 'state_id',
                'authentic': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def verify_professional_license(self, image_path: str, profession: str) -> Dict:
        """
        Complete professional license verification workflow
        
        Args:
            image_path: Path to license image
            profession: Type of profession (e.g., 'real_estate', 'mortgage')
            
        Returns:
            Dict containing complete verification results
        """
        try:
            # Step 1: Verify document authenticity
            auth_result = self.verify_document_authenticity(image_path)
            
            # Step 2: Extract text and data
            text_result = self.extract_text_from_document(image_path)
            
            # Step 3: Validate license data
            validation_result = {}
            if text_result.get('success'):
                structured_data = text_result['structured_data']
                
                # Check expiration date
                if 'expiration_date' in structured_data:
                    validation_result['expiration'] = self.check_expiration_date(
                        structured_data['expiration_date']
                    )
                
                # Validate license format
                if 'license_number' in structured_data and 'state' in structured_data:
                    state = structured_data['state']
                    license_number = structured_data['license_number']
                    validation_result['format_valid'] = self.validate_license_format(
                        license_number, state, profession
                    )
            
            # Combine all results
            complete_result = {
                'verification_type': 'professional_license',
                'profession': profession,
                'authentic': auth_result.get('authentic', False),
                'confidence_score': auth_result.get('confidence_score', 0),
                'fraud_indicators': auth_result.get('fraud_indicators', []),
                'extracted_data': text_result.get('structured_data', {}),
                'validation_results': validation_result,
                'timestamp': datetime.now().isoformat()
            }
            
            return complete_result
            
        except Exception as e:
            logger.error(f"Professional license verification error: {str(e)}")
            return {
                'verification_type': 'professional_license',
                'profession': profession,
                'authentic': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

