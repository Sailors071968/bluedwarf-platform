"""
Professional License Validation System for BlueDwarf
Handles real-time verification against state licensing databases
"""

import requests
import json
import re
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import logging
import os
import time
from urllib.parse import urlencode

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LicenseValidator:
    """
    Professional license validation system for real estate and mortgage professionals
    """
    
    def __init__(self):
        """Initialize the license validator with API configurations"""
        
        # API configurations
        self.propelus_api_key = os.getenv('PROPELUS_API_KEY')
        self.propelus_base_url = "https://api.propelus.com/v1"
        
        # State licensing authority URLs and patterns
        self.state_authorities = {
            'CA': {
                'real_estate': {
                    'authority': 'California Department of Real Estate',
                    'lookup_url': 'https://www2.dre.ca.gov/PublicASP/pplinfo.asp',
                    'license_pattern': r'^0\d{7}$',
                    'api_available': True
                },
                'mortgage': {
                    'authority': 'California Department of Financial Protection and Innovation',
                    'lookup_url': 'https://dfpi.ca.gov/licensees/',
                    'license_pattern': r'^CA-MLO\d{8}$',
                    'api_available': False
                }
            },
            'TX': {
                'real_estate': {
                    'authority': 'Texas Real Estate Commission',
                    'lookup_url': 'https://www.trec.texas.gov/apps/license-holder-search',
                    'license_pattern': r'^\d{6}$',
                    'api_available': True
                },
                'mortgage': {
                    'authority': 'Texas Department of Savings and Mortgage Lending',
                    'lookup_url': 'https://www.sml.texas.gov/licensee-search',
                    'license_pattern': r'^\d{6}$',
                    'api_available': False
                }
            },
            'FL': {
                'real_estate': {
                    'authority': 'Florida Department of Business and Professional Regulation',
                    'lookup_url': 'https://www.myfloridalicense.com/LicenseDetail.asp',
                    'license_pattern': r'^[A-Z]{2}\d{7}$',
                    'api_available': True
                },
                'mortgage': {
                    'authority': 'Florida Office of Financial Regulation',
                    'lookup_url': 'https://flofr.gov/sitePages/LicenseeSearch.htm',
                    'license_pattern': r'^LO\d{8}$',
                    'api_available': False
                }
            },
            'NY': {
                'real_estate': {
                    'authority': 'New York Department of State',
                    'lookup_url': 'https://appext20.dos.ny.gov/nydos/selSearchType.do',
                    'license_pattern': r'^\d{8}$',
                    'api_available': False
                },
                'mortgage': {
                    'authority': 'New York Department of Financial Services',
                    'lookup_url': 'https://myportal.dfs.ny.gov/web/guest-applications/mortgage-loan-originator-search',
                    'license_pattern': r'^\d{8}$',
                    'api_available': False
                }
            },
            'WA': {
                'real_estate': {
                    'authority': 'Washington Department of Licensing',
                    'lookup_url': 'https://fortress.wa.gov/dol/dolprod/bpdLicenseQuery/',
                    'license_pattern': r'^\d{8}$',
                    'api_available': True
                },
                'mortgage': {
                    'authority': 'Washington Department of Financial Institutions',
                    'lookup_url': 'https://www.dfi.wa.gov/consumers/licensed-professionals',
                    'license_pattern': r'^\d{8}$',
                    'api_available': False
                }
            }
        }
        
        # NMLS (Nationwide Multistate Licensing System) for mortgage professionals
        self.nmls_base_url = "https://www.nmlsconsumeraccess.org"
        
        # Rate limiting
        self.last_request_time = {}
        self.min_request_interval = 1.0  # Minimum seconds between requests

    def validate_license(self, license_number: str, state: str, profession: str, 
                        licensee_name: str = None) -> Dict:
        """
        Validate professional license against state authority
        
        Args:
            license_number: License number to validate
            state: State abbreviation (e.g., 'CA', 'TX')
            profession: Profession type ('real_estate' or 'mortgage')
            licensee_name: Name of licensee for additional verification
            
        Returns:
            Dict containing validation results
        """
        try:
            # Validate input parameters
            if not self._validate_inputs(license_number, state, profession):
                return {
                    'valid': False,
                    'error': 'Invalid input parameters',
                    'timestamp': datetime.now().isoformat()
                }
            
            # Get state authority information
            authority_info = self.state_authorities.get(state, {}).get(profession, {})
            if not authority_info:
                return {
                    'valid': False,
                    'error': f'No validation available for {profession} in {state}',
                    'timestamp': datetime.now().isoformat()
                }
            
            # Validate license format
            format_valid = self._validate_license_format(
                license_number, authority_info.get('license_pattern', '')
            )
            
            if not format_valid:
                return {
                    'valid': False,
                    'error': 'Invalid license number format',
                    'format_check': False,
                    'timestamp': datetime.now().isoformat()
                }
            
            # Perform validation based on available methods
            validation_result = None
            
            # Try API validation first (most reliable)
            if authority_info.get('api_available'):
                validation_result = self._validate_via_api(
                    license_number, state, profession, licensee_name
                )
            
            # Fallback to web scraping if API not available
            if not validation_result or not validation_result.get('success'):
                validation_result = self._validate_via_web_lookup(
                    license_number, state, profession, licensee_name, authority_info
                )
            
            # Special handling for mortgage professionals (NMLS)
            if profession == 'mortgage' and not validation_result.get('success'):
                nmls_result = self._validate_via_nmls(license_number, licensee_name)
                if nmls_result.get('success'):
                    validation_result = nmls_result
            
            # Format final result
            final_result = {
                'valid': validation_result.get('valid', False),
                'license_number': license_number,
                'state': state,
                'profession': profession,
                'authority': authority_info.get('authority', 'Unknown'),
                'format_check': True,
                'validation_method': validation_result.get('method', 'unknown'),
                'license_details': validation_result.get('details', {}),
                'timestamp': datetime.now().isoformat()
            }
            
            if validation_result.get('error'):
                final_result['error'] = validation_result['error']
            
            return final_result
            
        except Exception as e:
            logger.error(f"License validation error: {str(e)}")
            return {
                'valid': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def _validate_inputs(self, license_number: str, state: str, profession: str) -> bool:
        """Validate input parameters"""
        if not license_number or not state or not profession:
            return False
        
        if state not in self.state_authorities:
            return False
        
        if profession not in ['real_estate', 'mortgage']:
            return False
        
        return True

    def _validate_license_format(self, license_number: str, pattern: str) -> bool:
        """Validate license number format against state pattern"""
        if not pattern:
            return True  # No pattern available, assume valid
        
        try:
            return bool(re.match(pattern, license_number.upper()))
        except Exception:
            return False

    def _validate_via_api(self, license_number: str, state: str, profession: str, 
                         licensee_name: str = None) -> Dict:
        """
        Validate license using official state APIs
        
        Args:
            license_number: License number to validate
            state: State abbreviation
            profession: Profession type
            licensee_name: Name for additional verification
            
        Returns:
            Dict containing API validation results
        """
        try:
            # Rate limiting
            self._enforce_rate_limit(f"{state}_{profession}")
            
            # Use Propelus API for primary source verification
            if self.propelus_api_key:
                return self._validate_via_propelus(
                    license_number, state, profession, licensee_name
                )
            
            # Fallback to direct state API calls
            return self._validate_via_state_api(
                license_number, state, profession, licensee_name
            )
            
        except Exception as e:
            logger.error(f"API validation error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'method': 'api'
            }

    def _validate_via_propelus(self, license_number: str, state: str, profession: str, 
                              licensee_name: str = None) -> Dict:
        """Validate using Propelus Primary Source Verification API"""
        try:
            headers = {
                'Authorization': f'Bearer {self.propelus_api_key}',
                'Content-Type': 'application/json'
            }
            
            # Map profession to Propelus categories
            profession_mapping = {
                'real_estate': 'real_estate_agent',
                'mortgage': 'mortgage_loan_originator'
            }
            
            payload = {
                'license_number': license_number,
                'state': state,
                'profession': profession_mapping.get(profession, profession),
                'verification_type': 'primary_source'
            }
            
            if licensee_name:
                payload['licensee_name'] = licensee_name
            
            response = requests.post(
                f"{self.propelus_base_url}/verify-license",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'valid': data.get('valid', False),
                    'method': 'propelus_api',
                    'details': {
                        'licensee_name': data.get('licensee_name'),
                        'license_status': data.get('status'),
                        'issue_date': data.get('issue_date'),
                        'expiration_date': data.get('expiration_date'),
                        'license_type': data.get('license_type'),
                        'verification_date': data.get('verification_date')
                    }
                }
            else:
                return {
                    'success': False,
                    'error': f'Propelus API error: {response.status_code}',
                    'method': 'propelus_api'
                }
                
        except Exception as e:
            logger.error(f"Propelus validation error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'method': 'propelus_api'
            }

    def _validate_via_state_api(self, license_number: str, state: str, profession: str, 
                               licensee_name: str = None) -> Dict:
        """Validate using direct state API calls"""
        try:
            # California Real Estate
            if state == 'CA' and profession == 'real_estate':
                return self._validate_ca_real_estate(license_number, licensee_name)
            
            # Texas Real Estate
            elif state == 'TX' and profession == 'real_estate':
                return self._validate_tx_real_estate(license_number, licensee_name)
            
            # Florida Real Estate
            elif state == 'FL' and profession == 'real_estate':
                return self._validate_fl_real_estate(license_number, licensee_name)
            
            # Washington Real Estate
            elif state == 'WA' and profession == 'real_estate':
                return self._validate_wa_real_estate(license_number, licensee_name)
            
            else:
                return {
                    'success': False,
                    'error': 'Direct API not available for this state/profession',
                    'method': 'state_api'
                }
                
        except Exception as e:
            logger.error(f"State API validation error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'method': 'state_api'
            }

    def _validate_ca_real_estate(self, license_number: str, licensee_name: str = None) -> Dict:
        """Validate California real estate license"""
        try:
            # California DRE public lookup
            params = {
                'LicenseNumber': license_number,
                'LicenseType': 'RE'
            }
            
            response = requests.get(
                'https://www2.dre.ca.gov/PublicASP/pplinfo.asp',
                params=params,
                timeout=30
            )
            
            if response.status_code == 200:
                # Parse response (simplified - would need full HTML parsing)
                content = response.text.lower()
                
                if 'license not found' in content or 'no records found' in content:
                    return {
                        'success': True,
                        'valid': False,
                        'method': 'ca_dre_api',
                        'details': {'status': 'not_found'}
                    }
                elif 'active' in content or 'current' in content:
                    return {
                        'success': True,
                        'valid': True,
                        'method': 'ca_dre_api',
                        'details': {'status': 'active'}
                    }
                else:
                    return {
                        'success': False,
                        'error': 'Could not parse response',
                        'method': 'ca_dre_api'
                    }
            else:
                return {
                    'success': False,
                    'error': f'API request failed: {response.status_code}',
                    'method': 'ca_dre_api'
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'method': 'ca_dre_api'
            }

    def _validate_via_nmls(self, license_number: str, licensee_name: str = None) -> Dict:
        """
        Validate mortgage license via NMLS Consumer Access
        
        Args:
            license_number: NMLS license number
            licensee_name: Name for verification
            
        Returns:
            Dict containing NMLS validation results
        """
        try:
            # Rate limiting for NMLS
            self._enforce_rate_limit('nmls')
            
            # NMLS Consumer Access API (if available) or web lookup
            params = {
                'searchType': 'individual',
                'searchValue': license_number
            }
            
            if licensee_name:
                params['name'] = licensee_name
            
            # Note: NMLS doesn't provide a public API, so this would require web scraping
            # For production, consider using a service like Propelus that has NMLS access
            
            return {
                'success': False,
                'error': 'NMLS validation requires specialized service',
                'method': 'nmls',
                'recommendation': 'Use Propelus or similar service for NMLS validation'
            }
            
        except Exception as e:
            logger.error(f"NMLS validation error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'method': 'nmls'
            }

    def _validate_via_web_lookup(self, license_number: str, state: str, profession: str, 
                                licensee_name: str, authority_info: Dict) -> Dict:
        """
        Validate license via web scraping (fallback method)
        
        Args:
            license_number: License number to validate
            state: State abbreviation
            profession: Profession type
            licensee_name: Name for verification
            authority_info: State authority information
            
        Returns:
            Dict containing web lookup results
        """
        try:
            # Rate limiting
            self._enforce_rate_limit(f"web_{state}_{profession}")
            
            lookup_url = authority_info.get('lookup_url')
            if not lookup_url:
                return {
                    'success': False,
                    'error': 'No lookup URL available',
                    'method': 'web_lookup'
                }
            
            # This is a simplified example - production implementation would need
            # specific parsing logic for each state's website
            
            return {
                'success': False,
                'error': 'Web scraping not implemented for this state',
                'method': 'web_lookup',
                'lookup_url': lookup_url,
                'recommendation': 'Manual verification required'
            }
            
        except Exception as e:
            logger.error(f"Web lookup error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'method': 'web_lookup'
            }

    def _enforce_rate_limit(self, key: str):
        """Enforce rate limiting for API requests"""
        current_time = time.time()
        last_time = self.last_request_time.get(key, 0)
        
        time_diff = current_time - last_time
        if time_diff < self.min_request_interval:
            sleep_time = self.min_request_interval - time_diff
            time.sleep(sleep_time)
        
        self.last_request_time[key] = time.time()

    def batch_validate_licenses(self, licenses: List[Dict]) -> List[Dict]:
        """
        Validate multiple licenses in batch
        
        Args:
            licenses: List of license dictionaries with keys:
                     'license_number', 'state', 'profession', 'licensee_name'
                     
        Returns:
            List of validation results
        """
        results = []
        
        for license_info in licenses:
            try:
                result = self.validate_license(
                    license_info.get('license_number'),
                    license_info.get('state'),
                    license_info.get('profession'),
                    license_info.get('licensee_name')
                )
                
                result['batch_index'] = len(results)
                results.append(result)
                
                # Rate limiting between batch requests
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Batch validation error for license {license_info}: {str(e)}")
                results.append({
                    'valid': False,
                    'error': str(e),
                    'batch_index': len(results),
                    'timestamp': datetime.now().isoformat()
                })
        
        return results

    def get_supported_states_and_professions(self) -> Dict:
        """
        Get list of supported states and professions for validation
        
        Returns:
            Dict containing supported combinations
        """
        supported = {}
        
        for state, professions in self.state_authorities.items():
            supported[state] = {}
            for profession, info in professions.items():
                supported[state][profession] = {
                    'authority': info.get('authority'),
                    'api_available': info.get('api_available', False),
                    'license_pattern': info.get('license_pattern'),
                    'lookup_url': info.get('lookup_url')
                }
        
        return supported

    def validate_license_comprehensive(self, license_number: str, state: str, 
                                     profession: str, licensee_name: str = None,
                                     additional_checks: bool = True) -> Dict:
        """
        Comprehensive license validation with additional verification checks
        
        Args:
            license_number: License number to validate
            state: State abbreviation
            profession: Profession type
            licensee_name: Name for verification
            additional_checks: Whether to perform additional verification checks
            
        Returns:
            Dict containing comprehensive validation results
        """
        try:
            # Primary validation
            primary_result = self.validate_license(
                license_number, state, profession, licensee_name
            )
            
            comprehensive_result = {
                'license_number': license_number,
                'state': state,
                'profession': profession,
                'licensee_name': licensee_name,
                'primary_validation': primary_result,
                'additional_checks': {},
                'overall_valid': primary_result.get('valid', False),
                'confidence_score': 0.0,
                'timestamp': datetime.now().isoformat()
            }
            
            if additional_checks and primary_result.get('valid'):
                # Additional verification checks
                additional_results = {}
                
                # Cross-reference with NMLS if mortgage professional
                if profession == 'mortgage':
                    nmls_result = self._validate_via_nmls(license_number, licensee_name)
                    additional_results['nmls_check'] = nmls_result
                
                # Check for disciplinary actions (if API available)
                disciplinary_result = self._check_disciplinary_actions(
                    license_number, state, profession
                )
                additional_results['disciplinary_check'] = disciplinary_result
                
                comprehensive_result['additional_checks'] = additional_results
            
            # Calculate confidence score
            confidence_score = self._calculate_confidence_score(comprehensive_result)
            comprehensive_result['confidence_score'] = confidence_score
            
            # Final validation decision
            comprehensive_result['overall_valid'] = (
                primary_result.get('valid', False) and 
                confidence_score >= 70.0
            )
            
            return comprehensive_result
            
        except Exception as e:
            logger.error(f"Comprehensive validation error: {str(e)}")
            return {
                'license_number': license_number,
                'state': state,
                'profession': profession,
                'overall_valid': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def _check_disciplinary_actions(self, license_number: str, state: str, 
                                   profession: str) -> Dict:
        """Check for disciplinary actions against the license"""
        try:
            # This would require access to state disciplinary databases
            # Implementation depends on state-specific APIs
            
            return {
                'checked': False,
                'error': 'Disciplinary check not implemented',
                'recommendation': 'Manual verification recommended'
            }
            
        except Exception as e:
            return {
                'checked': False,
                'error': str(e)
            }

    def _calculate_confidence_score(self, validation_result: Dict) -> float:
        """Calculate confidence score based on validation results"""
        try:
            score = 0.0
            
            # Primary validation weight: 70%
            if validation_result['primary_validation'].get('valid'):
                score += 70.0
            
            # Method reliability weight: 20%
            method = validation_result['primary_validation'].get('validation_method', '')
            if 'api' in method.lower():
                score += 20.0
            elif 'web' in method.lower():
                score += 10.0
            
            # Additional checks weight: 10%
            additional_checks = validation_result.get('additional_checks', {})
            if additional_checks:
                valid_additional = sum(
                    1 for check in additional_checks.values() 
                    if check.get('valid', False) or check.get('checked', False)
                )
                if valid_additional > 0:
                    score += 10.0
            
            return min(100.0, score)
            
        except Exception:
            return 0.0

