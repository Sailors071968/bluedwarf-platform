"""
Facial Recognition Verification System for BlueDwarf
Handles live photo verification against state ID photos
"""

import cv2
import face_recognition
import numpy as np
import boto3
import base64
import json
import os
from typing import Dict, List, Tuple, Optional
from PIL import Image
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FacialRecognitionVerifier:
    """
    Facial recognition system for verifying live photos against state ID photos
    """
    
    def __init__(self):
        """Initialize the facial recognition verifier"""
        self.rekognition = boto3.client(
            'rekognition',
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
            region_name=os.getenv('AWS_REGION', 'us-east-1')
        )
        
        # Verification thresholds
        self.similarity_threshold = 85.0  # Minimum similarity percentage
        self.confidence_threshold = 90.0  # Minimum confidence for face detection
        self.max_faces_allowed = 1  # Only one face should be in live photo
        
    def verify_live_photo(self, live_photo_path: str, id_photo_path: str) -> Dict:
        """
        Verify that live photo matches the photo on state ID
        
        Args:
            live_photo_path: Path to live photo taken by user
            id_photo_path: Path to state ID photo
            
        Returns:
            Dict containing verification results
        """
        try:
            # Step 1: Validate both images
            live_validation = self._validate_live_photo(live_photo_path)
            id_validation = self._validate_id_photo(id_photo_path)
            
            if not live_validation['valid'] or not id_validation['valid']:
                return {
                    'verified': False,
                    'similarity_score': 0.0,
                    'confidence_score': 0.0,
                    'error': 'Photo validation failed',
                    'validation_details': {
                        'live_photo': live_validation,
                        'id_photo': id_validation
                    },
                    'timestamp': datetime.now().isoformat()
                }
            
            # Step 2: Perform facial recognition comparison
            comparison_result = self._compare_faces(live_photo_path, id_photo_path)
            
            # Step 3: Additional verification using AWS Rekognition
            aws_result = self._aws_face_comparison(live_photo_path, id_photo_path)
            
            # Step 4: Combine results and make final decision
            final_result = self._analyze_verification_results(
                comparison_result, aws_result, live_validation, id_validation
            )
            
            return final_result
            
        except Exception as e:
            logger.error(f"Live photo verification error: {str(e)}")
            return {
                'verified': False,
                'similarity_score': 0.0,
                'confidence_score': 0.0,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def _validate_live_photo(self, photo_path: str) -> Dict:
        """
        Validate live photo for quality and authenticity
        
        Args:
            photo_path: Path to live photo
            
        Returns:
            Dict containing validation results
        """
        try:
            # Load image
            image = cv2.imread(photo_path)
            if image is None:
                return {'valid': False, 'error': 'Could not load image'}
            
            validation_result = {
                'valid': True,
                'quality_score': 100.0,
                'issues': []
            }
            
            # Check image dimensions
            height, width = image.shape[:2]
            if width < 300 or height < 300:
                validation_result['issues'].append('low_resolution')
                validation_result['quality_score'] -= 20
            
            # Check for blur
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()
            if blur_score < 100:
                validation_result['issues'].append('blurry_image')
                validation_result['quality_score'] -= 25
            
            # Check brightness
            brightness = np.mean(gray)
            if brightness < 50 or brightness > 200:
                validation_result['issues'].append('poor_lighting')
                validation_result['quality_score'] -= 15
            
            # Detect faces
            face_locations = face_recognition.face_locations(image)
            
            if len(face_locations) == 0:
                validation_result['valid'] = False
                validation_result['issues'].append('no_face_detected')
            elif len(face_locations) > 1:
                validation_result['issues'].append('multiple_faces')
                validation_result['quality_score'] -= 30
            
            # Check face size (should be prominent in photo)
            if face_locations:
                top, right, bottom, left = face_locations[0]
                face_area = (bottom - top) * (right - left)
                image_area = height * width
                face_ratio = face_area / image_area
                
                if face_ratio < 0.1:
                    validation_result['issues'].append('face_too_small')
                    validation_result['quality_score'] -= 20
            
            # Final validation
            if validation_result['quality_score'] < 50:
                validation_result['valid'] = False
            
            return validation_result
            
        except Exception as e:
            logger.error(f"Live photo validation error: {str(e)}")
            return {'valid': False, 'error': str(e)}

    def _validate_id_photo(self, photo_path: str) -> Dict:
        """
        Validate ID photo extracted from state ID
        
        Args:
            photo_path: Path to ID photo
            
        Returns:
            Dict containing validation results
        """
        try:
            # Load image
            image = cv2.imread(photo_path)
            if image is None:
                return {'valid': False, 'error': 'Could not load image'}
            
            validation_result = {
                'valid': True,
                'quality_score': 100.0,
                'issues': []
            }
            
            # Detect faces
            face_locations = face_recognition.face_locations(image)
            
            if len(face_locations) == 0:
                validation_result['valid'] = False
                validation_result['issues'].append('no_face_detected')
            elif len(face_locations) > 1:
                validation_result['issues'].append('multiple_faces')
                validation_result['quality_score'] -= 20
            
            # Check image quality
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Check for sufficient contrast
            contrast = gray.std()
            if contrast < 30:
                validation_result['issues'].append('low_contrast')
                validation_result['quality_score'] -= 15
            
            return validation_result
            
        except Exception as e:
            logger.error(f"ID photo validation error: {str(e)}")
            return {'valid': False, 'error': str(e)}

    def _compare_faces(self, live_photo_path: str, id_photo_path: str) -> Dict:
        """
        Compare faces using face_recognition library
        
        Args:
            live_photo_path: Path to live photo
            id_photo_path: Path to ID photo
            
        Returns:
            Dict containing comparison results
        """
        try:
            # Load images
            live_image = face_recognition.load_image_file(live_photo_path)
            id_image = face_recognition.load_image_file(id_photo_path)
            
            # Get face encodings
            live_encodings = face_recognition.face_encodings(live_image)
            id_encodings = face_recognition.face_encodings(id_image)
            
            if not live_encodings or not id_encodings:
                return {
                    'success': False,
                    'error': 'Could not extract face encodings',
                    'similarity_score': 0.0
                }
            
            # Compare faces
            face_distances = face_recognition.face_distance(id_encodings, live_encodings[0])
            similarity_score = (1 - face_distances[0]) * 100  # Convert to percentage
            
            return {
                'success': True,
                'similarity_score': similarity_score,
                'face_distance': face_distances[0],
                'match': similarity_score >= self.similarity_threshold
            }
            
        except Exception as e:
            logger.error(f"Face comparison error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'similarity_score': 0.0
            }

    def _aws_face_comparison(self, live_photo_path: str, id_photo_path: str) -> Dict:
        """
        Compare faces using AWS Rekognition for additional verification
        
        Args:
            live_photo_path: Path to live photo
            id_photo_path: Path to ID photo
            
        Returns:
            Dict containing AWS comparison results
        """
        try:
            # Read images
            with open(live_photo_path, 'rb') as live_file:
                live_bytes = live_file.read()
            
            with open(id_photo_path, 'rb') as id_file:
                id_bytes = id_file.read()
            
            # Compare faces using AWS Rekognition
            response = self.rekognition.compare_faces(
                SourceImage={'Bytes': id_bytes},
                TargetImage={'Bytes': live_bytes},
                SimilarityThreshold=self.similarity_threshold
            )
            
            face_matches = response.get('FaceMatches', [])
            unmatched_faces = response.get('UnmatchedFaces', [])
            
            if face_matches:
                match = face_matches[0]
                similarity = match['Similarity']
                confidence = match['Face']['Confidence']
                
                return {
                    'success': True,
                    'similarity_score': similarity,
                    'confidence_score': confidence,
                    'match': similarity >= self.similarity_threshold,
                    'face_matches': len(face_matches),
                    'unmatched_faces': len(unmatched_faces)
                }
            else:
                return {
                    'success': True,
                    'similarity_score': 0.0,
                    'confidence_score': 0.0,
                    'match': False,
                    'face_matches': 0,
                    'unmatched_faces': len(unmatched_faces)
                }
                
        except Exception as e:
            logger.error(f"AWS face comparison error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'similarity_score': 0.0
            }

    def _analyze_verification_results(self, comparison_result: Dict, aws_result: Dict, 
                                    live_validation: Dict, id_validation: Dict) -> Dict:
        """
        Analyze all verification results to make final decision
        
        Args:
            comparison_result: Results from face_recognition library
            aws_result: Results from AWS Rekognition
            live_validation: Live photo validation results
            id_validation: ID photo validation results
            
        Returns:
            Dict containing final verification decision
        """
        try:
            # Initialize final result
            final_result = {
                'verified': False,
                'similarity_score': 0.0,
                'confidence_score': 0.0,
                'verification_method': 'multi_factor',
                'quality_issues': [],
                'verification_details': {
                    'face_recognition': comparison_result,
                    'aws_rekognition': aws_result,
                    'live_photo_validation': live_validation,
                    'id_photo_validation': id_validation
                },
                'timestamp': datetime.now().isoformat()
            }
            
            # Collect quality issues
            quality_issues = []
            quality_issues.extend(live_validation.get('issues', []))
            quality_issues.extend(id_validation.get('issues', []))
            final_result['quality_issues'] = quality_issues
            
            # Calculate weighted similarity score
            similarity_scores = []
            confidence_scores = []
            
            if comparison_result.get('success'):
                similarity_scores.append(comparison_result['similarity_score'])
                confidence_scores.append(90.0)  # face_recognition is generally reliable
            
            if aws_result.get('success'):
                similarity_scores.append(aws_result['similarity_score'])
                confidence_scores.append(aws_result.get('confidence_score', 85.0))
            
            if similarity_scores:
                # Weighted average of similarity scores
                final_result['similarity_score'] = np.mean(similarity_scores)
                final_result['confidence_score'] = np.mean(confidence_scores)
            
            # Decision logic
            verification_criteria = [
                final_result['similarity_score'] >= self.similarity_threshold,
                final_result['confidence_score'] >= self.confidence_threshold,
                live_validation['valid'],
                id_validation['valid'],
                len(quality_issues) <= 2  # Allow minor quality issues
            ]
            
            # Additional checks for high-confidence verification
            if comparison_result.get('success') and aws_result.get('success'):
                # Both methods must agree for high confidence
                both_match = (
                    comparison_result.get('match', False) and 
                    aws_result.get('match', False)
                )
                verification_criteria.append(both_match)
            
            # Final verification decision
            final_result['verified'] = all(verification_criteria)
            
            # Add verification confidence level
            if final_result['verified']:
                if final_result['similarity_score'] >= 95 and len(quality_issues) == 0:
                    final_result['confidence_level'] = 'high'
                elif final_result['similarity_score'] >= 90:
                    final_result['confidence_level'] = 'medium'
                else:
                    final_result['confidence_level'] = 'low'
            else:
                final_result['confidence_level'] = 'failed'
            
            return final_result
            
        except Exception as e:
            logger.error(f"Result analysis error: {str(e)}")
            return {
                'verified': False,
                'similarity_score': 0.0,
                'confidence_score': 0.0,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def extract_face_from_id(self, id_image_path: str, output_path: str) -> Dict:
        """
        Extract face photo from state ID image
        
        Args:
            id_image_path: Path to state ID image
            output_path: Path to save extracted face
            
        Returns:
            Dict containing extraction results
        """
        try:
            # Load image
            image = cv2.imread(id_image_path)
            if image is None:
                return {'success': False, 'error': 'Could not load image'}
            
            # Detect faces
            face_locations = face_recognition.face_locations(image)
            
            if not face_locations:
                return {'success': False, 'error': 'No face detected in ID'}
            
            if len(face_locations) > 1:
                return {'success': False, 'error': 'Multiple faces detected in ID'}
            
            # Extract face region
            top, right, bottom, left = face_locations[0]
            
            # Add padding around face
            padding = 20
            top = max(0, top - padding)
            left = max(0, left - padding)
            bottom = min(image.shape[0], bottom + padding)
            right = min(image.shape[1], right + padding)
            
            # Crop face
            face_image = image[top:bottom, left:right]
            
            # Save extracted face
            cv2.imwrite(output_path, face_image)
            
            return {
                'success': True,
                'face_location': (top, right, bottom, left),
                'face_size': (bottom - top, right - left),
                'output_path': output_path
            }
            
        except Exception as e:
            logger.error(f"Face extraction error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def detect_liveness(self, photo_path: str) -> Dict:
        """
        Basic liveness detection to prevent photo spoofing
        
        Args:
            photo_path: Path to live photo
            
        Returns:
            Dict containing liveness detection results
        """
        try:
            # Load image
            image = cv2.imread(photo_path)
            if image is None:
                return {'live': False, 'error': 'Could not load image'}
            
            liveness_result = {
                'live': True,
                'confidence': 100.0,
                'indicators': []
            }
            
            # Check for screen reflection patterns
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Detect edges (screens often have regular patterns)
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.sum(edges > 0) / edges.size
            
            if edge_density > 0.3:
                liveness_result['indicators'].append('high_edge_density')
                liveness_result['confidence'] -= 20
            
            # Check for uniform lighting (screens have uniform backlighting)
            brightness_std = np.std(gray)
            if brightness_std < 20:
                liveness_result['indicators'].append('uniform_lighting')
                liveness_result['confidence'] -= 25
            
            # Check for color temperature (screens often have blue tint)
            b, g, r = cv2.split(image)
            blue_ratio = np.mean(b) / (np.mean(g) + np.mean(r) + 1)
            if blue_ratio > 0.6:
                liveness_result['indicators'].append('blue_tint')
                liveness_result['confidence'] -= 15
            
            # Final liveness decision
            if liveness_result['confidence'] < 60:
                liveness_result['live'] = False
            
            return liveness_result
            
        except Exception as e:
            logger.error(f"Liveness detection error: {str(e)}")
            return {'live': False, 'error': str(e)}

    def comprehensive_verification(self, live_photo_path: str, id_image_path: str, 
                                 temp_dir: str = "/tmp") -> Dict:
        """
        Complete facial verification workflow
        
        Args:
            live_photo_path: Path to live photo
            id_image_path: Path to state ID image
            temp_dir: Directory for temporary files
            
        Returns:
            Dict containing complete verification results
        """
        try:
            # Step 1: Extract face from ID
            id_face_path = os.path.join(temp_dir, "extracted_id_face.jpg")
            extraction_result = self.extract_face_from_id(id_image_path, id_face_path)
            
            if not extraction_result['success']:
                return {
                    'verified': False,
                    'error': 'Could not extract face from ID',
                    'extraction_result': extraction_result,
                    'timestamp': datetime.now().isoformat()
                }
            
            # Step 2: Liveness detection
            liveness_result = self.detect_liveness(live_photo_path)
            
            # Step 3: Face verification
            verification_result = self.verify_live_photo(live_photo_path, id_face_path)
            
            # Step 4: Combine all results
            complete_result = {
                'verification_type': 'facial_recognition',
                'verified': (
                    verification_result.get('verified', False) and 
                    liveness_result.get('live', False)
                ),
                'similarity_score': verification_result.get('similarity_score', 0.0),
                'confidence_score': verification_result.get('confidence_score', 0.0),
                'liveness_detection': liveness_result,
                'face_extraction': extraction_result,
                'verification_details': verification_result.get('verification_details', {}),
                'timestamp': datetime.now().isoformat()
            }
            
            # Clean up temporary files
            try:
                if os.path.exists(id_face_path):
                    os.remove(id_face_path)
            except:
                pass
            
            return complete_result
            
        except Exception as e:
            logger.error(f"Comprehensive verification error: {str(e)}")
            return {
                'verification_type': 'facial_recognition',
                'verified': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

