# BlueDwarf Deployment Guide

Complete deployment guide for the BlueDwarf property analysis platform including frontend, backend, verification system, and email infrastructure.

## 🚀 Quick Deployment Overview

### Prerequisites
- **Domain**: bluedwarf.io (or your custom domain)
- **Web Server**: Apache/Nginx with SSL support
- **Python**: 3.11+ with pip and virtual environment
- **Database**: PostgreSQL (production) or SQLite (development)
- **Email Service**: Google Workspace Business Starter
- **Cloud Services**: AWS account for verification APIs

### Deployment Timeline
- **Frontend Deployment**: 30 minutes
- **Backend Setup**: 1-2 hours
- **Email System**: 2-24 hours (DNS propagation)
- **Verification System**: 2-3 hours
- **Complete Testing**: 1-2 hours

---

## 📁 Repository Structure

```
bluedwarf-github-repo/
├── frontend/                 # Website files (HTML/CSS/JS)
├── backend/                 # Flask application
├── verification-system/     # Identity verification modules
├── email-templates/         # Professional email templates
├── docs/                   # Documentation and guides
└── README.md               # Project overview
```

---

## 🌐 Frontend Deployment

### Step 1: Web Server Setup

**For Apache:**
```bash
# Install Apache with SSL
sudo apt update
sudo apt install apache2 apache2-utils ssl-cert

# Enable required modules
sudo a2enmod rewrite ssl headers

# Create virtual host
sudo nano /etc/apache2/sites-available/bluedwarf.conf
```

**Apache Virtual Host Configuration:**
```apache
<VirtualHost *:80>
    ServerName bluedwarf.io
    ServerAlias www.bluedwarf.io
    DocumentRoot /var/www/bluedwarf
    
    # Redirect to HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</VirtualHost>

<VirtualHost *:443>
    ServerName bluedwarf.io
    ServerAlias www.bluedwarf.io
    DocumentRoot /var/www/bluedwarf
    
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile /path/to/certificate.crt
    SSLCertificateKeyFile /path/to/private.key
    SSLCertificateChainFile /path/to/chain.crt
    
    # Security Headers
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"
    
    # Enable compression
    LoadModule deflate_module modules/mod_deflate.so
    <Location />
        SetOutputFilter DEFLATE
        SetEnvIfNoCase Request_URI \\.(?:gif|jpe?g|png)$ no-gzip dont-vary
        SetEnvIfNoCase Request_URI \\.(?:exe|t?gz|zip|bz2|sit|rar)$ no-gzip dont-vary
    </Location>
    
    ErrorLog ${APACHE_LOG_DIR}/bluedwarf_error.log
    CustomLog ${APACHE_LOG_DIR}/bluedwarf_access.log combined
</VirtualHost>
```

### Step 2: Deploy Frontend Files

```bash
# Create web directory
sudo mkdir -p /var/www/bluedwarf

# Copy frontend files
sudo cp frontend/*.html /var/www/bluedwarf/

# Set permissions
sudo chown -R www-data:www-data /var/www/bluedwarf
sudo chmod -R 755 /var/www/bluedwarf

# Enable site
sudo a2ensite bluedwarf.conf
sudo systemctl reload apache2
```

### Step 3: SSL Certificate Setup

**Using Let's Encrypt (Recommended):**
```bash
# Install Certbot
sudo apt install certbot python3-certbot-apache

# Obtain certificate
sudo certbot --apache -d bluedwarf.io -d www.bluedwarf.io

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## 🔧 Backend Deployment

### Step 1: Server Setup

```bash
# Install Python and dependencies
sudo apt update
sudo apt install python3.11 python3.11-venv python3-pip
sudo apt install postgresql postgresql-contrib
sudo apt install nginx supervisor

# Install system dependencies for verification
sudo apt install cmake build-essential
sudo apt install tesseract-ocr tesseract-ocr-eng
sudo apt install libopencv-dev python3-opencv
```

### Step 2: Application Setup

```bash
# Create application directory
sudo mkdir -p /opt/bluedwarf
cd /opt/bluedwarf

# Copy backend files
sudo cp -r /path/to/backend/* .
sudo cp -r /path/to/verification-system/* ./verification/

# Create virtual environment
sudo python3.11 -m venv venv
sudo chown -R bluedwarf:bluedwarf /opt/bluedwarf

# Switch to application user
sudo useradd -r -s /bin/false bluedwarf
sudo su - bluedwarf

# Activate virtual environment and install dependencies
source venv/bin/activate
pip install -r requirements.txt
```

### Step 3: Database Setup

```bash
# Create PostgreSQL database
sudo -u postgres createuser bluedwarf
sudo -u postgres createdb bluedwarf_db -O bluedwarf
sudo -u postgres psql -c "ALTER USER bluedwarf PASSWORD 'secure_password';"

# Initialize database
cd /opt/bluedwarf
source venv/bin/activate
python -c "from app import db; db.create_all()"
```

### Step 4: Environment Configuration

**Create `/opt/bluedwarf/.env`:**
```bash
# Flask Configuration
FLASK_ENV=production
SECRET_KEY=your_very_secure_secret_key_here
DATABASE_URL=postgresql://bluedwarf:secure_password@localhost/bluedwarf_db

# API Keys
RENTCAST_API_KEY=your_rentcast_api_key
GOOGLE_MAPS_API_KEY=your_google_maps_api_key

# AWS Configuration
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=us-east-1

# Verification APIs
ID_ANALYZER_API_KEY=your_id_analyzer_key
PROPELUS_API_KEY=your_propelus_api_key

# Email Configuration
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=support@bluedwarf.io
MAIL_PASSWORD=your_app_password

# Security
CORS_ORIGINS=https://bluedwarf.io,https://www.bluedwarf.io
```

### Step 5: Gunicorn Configuration

**Create `/opt/bluedwarf/gunicorn.conf.py`:**
```python
bind = "127.0.0.1:8000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True
```

### Step 6: Supervisor Configuration

**Create `/etc/supervisor/conf.d/bluedwarf.conf`:**
```ini
[program:bluedwarf]
command=/opt/bluedwarf/venv/bin/gunicorn -c gunicorn.conf.py app:app
directory=/opt/bluedwarf
user=bluedwarf
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/var/log/bluedwarf/app.log
stdout_logfile_maxbytes=50MB
stdout_logfile_backups=10
environment=PATH="/opt/bluedwarf/venv/bin"
```

### Step 7: Nginx Configuration

**Create `/etc/nginx/sites-available/bluedwarf-api`:**
```nginx
upstream bluedwarf_app {
    server 127.0.0.1:8000;
}

server {
    listen 80;
    server_name api.bluedwarf.io;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.bluedwarf.io;
    
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    
    # SSL Security
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    
    # Security Headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
    
    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req zone=api burst=20 nodelay;
    
    location / {
        proxy_pass http://bluedwarf_app;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # File upload size
    client_max_body_size 10M;
    
    # Logging
    access_log /var/log/nginx/bluedwarf-api.access.log;
    error_log /var/log/nginx/bluedwarf-api.error.log;
}
```

### Step 8: Start Services

```bash
# Create log directory
sudo mkdir -p /var/log/bluedwarf
sudo chown bluedwarf:bluedwarf /var/log/bluedwarf

# Start services
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start bluedwarf

# Enable Nginx site
sudo ln -s /etc/nginx/sites-available/bluedwarf-api /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 📧 Email System Deployment

### Step 1: Google Workspace Setup

**Domain Verification:**
1. Add TXT record to DNS:
   ```
   Type: TXT
   Name: @
   Value: google-site-verification=YOUR_VERIFICATION_CODE
   ```

2. Configure MX records:
   ```
   Priority: 1, Value: smtp.google.com
   Priority: 5, Value: smtp2.google.com
   Priority: 5, Value: smtp3.google.com
   Priority: 10, Value: smtp4.google.com
   ```

### Step 2: Email Authentication

**SPF Record:**
```
Type: TXT
Name: @
Value: v=spf1 include:_spf.google.com ~all
```

**DKIM Setup:**
1. Generate DKIM key in Google Admin Console
2. Add DKIM TXT record to DNS:
   ```
   Type: TXT
   Name: google._domainkey
   Value: [DKIM key from Google]
   ```

**DMARC Policy:**
```
Type: TXT
Name: _dmarc
Value: v=DMARC1; p=quarantine; rua=mailto:dmarc@bluedwarf.io; ruf=mailto:dmarc@bluedwarf.io; fo=1
```

### Step 3: Email Accounts Creation

Create these accounts in Google Workspace:
- **support@bluedwarf.io** - Customer service
- **info@bluedwarf.io** - General inquiries
- **partnerships@bluedwarf.io** - Business development

### Step 4: Email Template Implementation

```bash
# Copy email templates
sudo mkdir -p /opt/bluedwarf/templates/email
sudo cp email-templates/*.md /opt/bluedwarf/templates/email/

# Configure email service in Flask app
# Update app.py with email configuration
```

---

## 🔒 Verification System Deployment

### Step 1: AWS Services Setup

**IAM User Creation:**
```bash
# Create IAM user with permissions:
# - AmazonRekognitionFullAccess
# - AmazonS3FullAccess (for document storage)
```

**S3 Bucket Setup:**
```bash
# Create S3 bucket for document storage
aws s3 mb s3://bluedwarf-documents --region us-east-1

# Configure bucket policy for security
aws s3api put-bucket-policy --bucket bluedwarf-documents --policy file://bucket-policy.json
```

### Step 2: Verification APIs Setup

**ID Analyzer Account:**
1. Sign up at https://www.idanalyzer.com/
2. Get API key from dashboard
3. Configure rate limits and usage alerts

**Propelus Account (Optional):**
1. Contact Propelus for enterprise access
2. Configure primary source verification
3. Set up webhook endpoints

### Step 3: Document Storage Security

```bash
# Create secure document storage
sudo mkdir -p /opt/bluedwarf/storage/{documents,temp}
sudo chown -R bluedwarf:bluedwarf /opt/bluedwarf/storage
sudo chmod 700 /opt/bluedwarf/storage

# Configure encryption at rest
sudo apt install cryptsetup
sudo cryptsetup luksFormat /dev/sdb1
sudo cryptsetup luksOpen /dev/sdb1 bluedwarf-storage
sudo mkfs.ext4 /dev/mapper/bluedwarf-storage
sudo mount /dev/mapper/bluedwarf-storage /opt/bluedwarf/storage
```

### Step 4: Verification Workflow Testing

```bash
# Test document verification
cd /opt/bluedwarf
source venv/bin/activate
python -c "
from verification.document_verification import DocumentVerifier
verifier = DocumentVerifier()
result = verifier.verify_document_authenticity('test_id.jpg')
print(result)
"

# Test facial recognition
python -c "
from verification.facial_recognition import FacialRecognitionVerifier
verifier = FacialRecognitionVerifier()
result = verifier.verify_live_photo('live.jpg', 'id.jpg')
print(result)
"
```

---

## 🔍 Testing and Validation

### Step 1: Frontend Testing

```bash
# Test website functionality
curl -I https://bluedwarf.io
curl -I https://bluedwarf.io/about.html
curl -I https://bluedwarf.io/contact.html

# Test SSL configuration
openssl s_client -connect bluedwarf.io:443 -servername bluedwarf.io
```

### Step 2: Backend API Testing

```bash
# Test API endpoints
curl -X GET https://api.bluedwarf.io/health
curl -X POST https://api.bluedwarf.io/api/property-search \
  -H "Content-Type: application/json" \
  -d '{"address": "123 Main St, Sacramento, CA"}'
```

### Step 3: Email System Testing

```bash
# Test email delivery
python -c "
import smtplib
from email.mime.text import MIMEText

msg = MIMEText('Test email from BlueDwarf')
msg['Subject'] = 'Test Email'
msg['From'] = 'support@bluedwarf.io'
msg['To'] = 'test@example.com'

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login('support@bluedwarf.io', 'app_password')
server.send_message(msg)
server.quit()
print('Email sent successfully')
"
```

### Step 4: Verification System Testing

```bash
# Test complete verification workflow
python test_verification.py
```

---

## 📊 Monitoring and Maintenance

### Step 1: Log Management

**Configure log rotation:**
```bash
# Create logrotate configuration
sudo nano /etc/logrotate.d/bluedwarf

/var/log/bluedwarf/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 bluedwarf bluedwarf
    postrotate
        supervisorctl restart bluedwarf
    endscript
}
```

### Step 2: Monitoring Setup

**Install monitoring tools:**
```bash
# Install monitoring stack
sudo apt install prometheus node-exporter grafana

# Configure Prometheus
sudo nano /etc/prometheus/prometheus.yml
```

### Step 3: Backup Strategy

**Database backups:**
```bash
# Create backup script
sudo nano /opt/bluedwarf/backup.sh

#!/bin/bash
BACKUP_DIR="/opt/bluedwarf/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Database backup
pg_dump bluedwarf_db > $BACKUP_DIR/db_backup_$DATE.sql

# Document storage backup
tar -czf $BACKUP_DIR/documents_$DATE.tar.gz /opt/bluedwarf/storage/documents

# Upload to S3
aws s3 cp $BACKUP_DIR/ s3://bluedwarf-backups/ --recursive

# Cleanup old backups (keep 30 days)
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

# Schedule daily backups
sudo crontab -e
# Add: 0 2 * * * /opt/bluedwarf/backup.sh
```

### Step 4: Security Updates

```bash
# Create update script
sudo nano /opt/bluedwarf/update.sh

#!/bin/bash
# System updates
sudo apt update && sudo apt upgrade -y

# Python package updates
cd /opt/bluedwarf
source venv/bin/activate
pip list --outdated --format=freeze | grep -v '^\-e' | cut -d = -f 1 | xargs -n1 pip install -U

# Restart services
sudo supervisorctl restart bluedwarf
sudo systemctl reload nginx

# Security scan
sudo apt install lynis
sudo lynis audit system
```

---

## 🚨 Troubleshooting

### Common Issues

**1. DNS Propagation Delays**
```bash
# Check DNS propagation
dig TXT bluedwarf.io
nslookup -type=TXT bluedwarf.io 8.8.8.8
```

**2. SSL Certificate Issues**
```bash
# Check certificate validity
openssl x509 -in /path/to/certificate.crt -text -noout
```

**3. Email Delivery Problems**
```bash
# Check email authentication
dig TXT bluedwarf.io | grep spf
dig TXT google._domainkey.bluedwarf.io
dig TXT _dmarc.bluedwarf.io
```

**4. Verification API Errors**
```bash
# Check API connectivity
curl -I https://api.idanalyzer.com
curl -I https://rekognition.us-east-1.amazonaws.com
```

### Performance Optimization

**1. Database Optimization**
```sql
-- Create indexes for common queries
CREATE INDEX idx_licenses_state_profession ON licenses(state, profession);
CREATE INDEX idx_verifications_timestamp ON verifications(timestamp);
```

**2. Caching Configuration**
```bash
# Install Redis for caching
sudo apt install redis-server
pip install redis flask-caching
```

**3. CDN Setup**
```bash
# Configure CloudFlare or AWS CloudFront
# Update DNS to point to CDN
```

---

## 📋 Deployment Checklist

### Pre-Deployment
- [ ] Domain registered and DNS configured
- [ ] SSL certificates obtained
- [ ] API keys and credentials secured
- [ ] Database created and configured
- [ ] Email accounts created in Google Workspace

### Frontend Deployment
- [ ] Web server configured with SSL
- [ ] HTML files uploaded and permissions set
- [ ] Navigation tested between all pages
- [ ] Contact form functionality verified
- [ ] Property search feature tested

### Backend Deployment
- [ ] Python environment set up
- [ ] Dependencies installed
- [ ] Database migrations completed
- [ ] Environment variables configured
- [ ] API endpoints tested
- [ ] Gunicorn and Nginx configured

### Email System
- [ ] Google Workspace domain verified
- [ ] MX records configured
- [ ] SPF, DKIM, DMARC records added
- [ ] Email accounts created and tested
- [ ] Email templates imported

### Verification System
- [ ] AWS services configured
- [ ] Document storage secured
- [ ] Facial recognition tested
- [ ] License validation tested
- [ ] Complete workflow verified

### Security and Monitoring
- [ ] Security headers configured
- [ ] Rate limiting implemented
- [ ] Monitoring tools installed
- [ ] Backup strategy implemented
- [ ] Log rotation configured

### Final Testing
- [ ] End-to-end user workflow tested
- [ ] Performance benchmarks met
- [ ] Security scan completed
- [ ] Documentation updated
- [ ] Team training completed

---

## 🎯 Go-Live Process

### 1. Final Pre-Launch Check (T-24 hours)
- Complete system backup
- Final security scan
- Performance testing
- DNS TTL reduction

### 2. Launch Day (T-0)
- Switch DNS to production servers
- Monitor system performance
- Test all critical functions
- Verify email delivery

### 3. Post-Launch (T+24 hours)
- Monitor error logs
- Check performance metrics
- Verify backup systems
- Update documentation

### 4. Week 1 Monitoring
- Daily performance reviews
- User feedback collection
- System optimization
- Security monitoring

---

**🎉 Congratulations! Your BlueDwarf platform is now live and ready to revolutionize property analysis!**

For support and updates, contact: support@bluedwarf.io

